package task.QC;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

public class Registerpage  extends pageBase{

	public Registerpage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath="//*[@id=\"header\"]/div/div[2]/a[3]")
	WebElement Account;
	
	@FindBy(linkText="Register")
	WebElement Register;
	
	@FindBy(name="firstname")
	WebElement FirstName;
	
	@FindBy(name="lastname")
	WebElement LastName;
	
	@FindBy(name="email")
	WebElement Email;
	
	@FindBy(id="password")
	WebElement UserPass;
	
	@FindBy(id="confirmation")
	WebElement ConfirmPass
	;
	
	@FindBy(xpath="//*[@id=\"form-validate\"]/div[2]/button")
	WebElement RegisterButton;
	
		public void click_Registerbutton() {
		RegisterButton.click();
//		Thread.sleep(4000);

	}
       public void clickAccount() {
    	   Account.click();
       }
       public void register() {
    	   Register.click();
       }
	public void Userregister(String frname ,String lsName ,String email,String psword,String Confirm) {

		FirstName.sendKeys(frname);
		LastName.sendKeys(lsName);
		Email.sendKeys(email);
		UserPass.sendKeys(psword);
		ConfirmPass.sendKeys(Confirm);
		
	}
	

	
	
	
	
	}
