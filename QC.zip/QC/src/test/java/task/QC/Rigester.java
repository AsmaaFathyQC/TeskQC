package task.QC;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Rigester {
	Registerpage registerobject;
	
	public static WebDriver driver;

	@BeforeTest
	public void startDriver() { 

		WebDriverManager.chromedriver().setup();

		driver = new ChromeDriver();
		driver.navigate().to("http://magento-demo.lexiconn.com/");
		
		driver.manage().window().maximize();
		
		
	}
	@Test
	public void rigester()
	{
		registerobject = new Registerpage(driver);
		registerobject.clickAccount();
		registerobject.register();
		registerobject.Userregister("asmaa12", "fathy", "asmaa110@test.com", "LOly123", "LOly123");
		registerobject.click_Registerbutton();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertEquals(driver.getTitle(), "My Account");
	}
	



@AfterTest
public void stopDriver() {

//	driver.quit();

}
}
